// models/User.js

class User {
    constructor(id, nombre, cedula) {
      this.id = id;
      this.nombre = nombre;
      this.cedula = cedula;
    }
  }
  
  module.exports = User;
  